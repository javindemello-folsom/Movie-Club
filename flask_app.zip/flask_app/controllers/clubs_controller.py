from flask import Flask, render_template, request, redirect, session, flash
from flask_app import app
from flask_app.models.user_model import User
from flask_app.models.club_model import Club, Member
from flask_app.models.movies_model import Movie
from flask_bcrypt import Bcrypt
bcrypt = Bcrypt(app)

@app.route('/clubs/new')
def new_club():
    if 'user_id' not in session:
        return redirect('/')
    return render_template("new_club.html")

@app.route('/clubs/add', methods=["POST"])
def add_club():
    if not Club.validate_new_club(request.form):
        return redirect('/clubs/new')
    club_data = {
        "name": request.form["name"]
    }
    Club.save(club_data)
    print('NEW CLUB ID')
    print(session['club_id'])
    owner_data = {
        'name':session['fname'],
        'email':session['email'],
        'status':'Owner',
        'user_id':session['user_id'],
        'club_id':session['club_id']
    }
    Member.add_member(owner_data)
    return redirect(f"/clubs/edit/{session['club_id']}")

@app.route('/clubs/edit/<int:club_id>')
def edit_club(club_id):
    # user = User.get_by_club(club_id)
    # if session['user_id'] != user.id:
    #     return redirect('/dashboard')
    club = Club.get_by_id(club_id)
    members = Member.get_members_by_club(club_id)
    return render_template("edit_club.html", club_id = club_id, club = club, members = members)

@app.route('/update/<int:club_id>', methods=["POST"])
def update_club(club_id):
    if not Club.validate_club(request.form):
        return redirect(f'/clubs/edit/{club_id}')
    data = {
        'name':request.form['name'],
        'club_id':club_id
    }
    Club.update(data)
    return redirect('/dashboard')

@app.route('/clubs/delete/<int:club_id>', methods=['POST'])
def delete_club(club_id):
    Club.delete(club_id)
    return redirect('/dashboard')

@app.route('/clubs/<int:club_id>')
def view_club(club_id):
    session['club_id'] = club_id
    session['search_key'] = ""
    club = Club.get_by_id(club_id)
    movies = Movie.get_by_id(club_id)
    return render_template("view_club.html", club_id = club_id, club = club, movies = movies)

@app.route('/clubs/add_members/<int:club_id>', methods=['POST'])
def add_new_member(club_id):
    member_data = {
        'name':request.form['member_name'],
        'email':request.form['member_email'],
        'status':request.form['member_status'],
        'user_id': session['user_id'],
        'club_id':club_id
    }
    Member.add_member(member_data)
    return redirect(f'/clubs/edit/{club_id}')