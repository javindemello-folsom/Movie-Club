from flask import Flask, render_template, request, redirect, session, flash
from flask_app import app
from flask_app.models.user_model import User
from flask_app.models.club_model import Club
from flask_app.models.movies_model import Movie
from flask_bcrypt import Bcrypt
import requests, json
import tmdbsimple as tmdb
tmdb.API_KEY = 'df37e82fe4df884b36076a43303b68ae'
tmdb.REQUESTS_TIMEOUT = 5  # timeout seconds, for both connect and read
bcrypt = Bcrypt(app)

@app.route('/search_movies')
def pick_movie():
    search = tmdb.Search()
    key = session.get('search_key')
    response = search.movie(query=key)
    # for s in search.results:
    #     print(s['title'])
    search_results = search.results
    return render_template("search_movies.html", search_results = search_results)

@app.route('/search_results', methods=["POST"])
def search_movies():
    session["search_key"] = request.form["search_key"]
    return redirect("/search_movies")

@app.route('/add_movie/<int:id>')
def show_movie(id):
    movie = tmdb.Movies(id)
    response = movie.info()
    session['pick_title'] = movie.title
    session['pick_date'] = movie.release_date
    session['pick_genres'] = movie.genres
    session['pick_runtime'] = movie.runtime
    return render_template("add_movie.html")

@app.route('/add_movie')
def show_movie_manual():
    session['pick_title'] = ""
    session['pick_date'] = ""
    session['pick_genres'] = ""
    session['pick_runtime'] = ""
    return render_template("add_movie.html")

@app.route('/added_movie', methods=['POST'])
def add_movie():
    data = {
        'title': request.form['title'],
        'release_date': request.form['date_released'],
        'runtime': request.form['runtime'],
        'date_watched': request.form['date_watched'],
        'club_id': session['club_id']
    }
    Movie.save(data)
    return redirect(f"/clubs/{session['club_id']}")