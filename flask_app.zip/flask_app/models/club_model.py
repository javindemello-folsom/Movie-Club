from flask_app.config.mysqlconnection import connectToMySQL

from flask import flash, session

class Club:
    DB = "movie_club"
    def __init__( self , data ):
        self.id = data['id']
        self.name = data['name']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.membership = []
        
    @classmethod
    def get_all(cls):
        query = "SELECT * FROM clubs;"
        clubs = []
        results = connectToMySQL(cls.DB).query_db(query)
        for row in results:
            clubs.append(cls(row))
        return clubs
    
    @classmethod
    def get_all_by_user(cls,user_id):
        query = "SELECT * FROM clubs LEFT JOIN membership ON clubs.id = membership.club_id LEFT JOIN users ON users.id = membership.user_id WHERE users.id = %(user_id)s;"
        clubs = []
        results = connectToMySQL(cls.DB).query_db(query,{"user_id":user_id})
        return cls(results[0])
    
    @classmethod
    def get_by_id(cls,club_id):
        query = "SELECT * FROM clubs WHERE id = %(id)s;"
        results = connectToMySQL(cls.DB).query_db(query,{'id':club_id})
        return cls(results[0])
    
    @classmethod
    def save(cls, data ):
        query = "INSERT INTO clubs ( name , created_at , updated_at ) VALUES ( %(name)s , NOW() , NOW() );"
        results = connectToMySQL(cls.DB).query_db( query, data )
        session['club_id'] = results
        return results
    
    @classmethod
    def update(cls, data):
        query = "UPDATE clubs SET name = %(name)s, updated_at = NOW()  WHERE id = %(club_id)s"
        results = connectToMySQL(cls.DB).query_db(query, data)
        return results
    
    @classmethod
    def delete(cls, club_id):
        query ="DELETE from clubs WHERE id = %(id)s"
        return connectToMySQL(cls.DB).query_db(query, {'id':club_id})
    
    @staticmethod
    def validate_club( club ):
        is_valid = True
        
        if len(club['name']) < 1:
            is_valid = False
            flash(u'Club name required.','club')
        
        # if len(club['member_name']) < 1:
        #     is_valid = False
        #     flash(u'Member name required.','club')
        
        # if len(club['member_email']) < 1:
        #     is_valid = False
        #     flash(u'Member email required.','club')
        
        return is_valid
    
    @staticmethod
    def validate_new_club( club ):
        is_valid = True
        
        if len(club['name']) < 1:
            is_valid = False
            flash(u'Club name required.','club')
        
        return is_valid
    
    
    
class Member:
    DB = "movie_club"
    def __init__( self , data ):
        self.id = data['id']
        self.name = data['name']
        self.email = data['email']
        self.status = data['status']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        
    @classmethod
    def add_member(cls, data ):
        query = "INSERT INTO membership (name, email, status, created_at, updated_at, user_id, club_id) VALUES (%(name)s, %(email)s, %(status)s, NOW(), NOW(), %(user_id)s, %(club_id)s );"
        return connectToMySQL(cls.DB).query_db(query, data)
    
    def add_new_member(cls, data ):
        query = "INSERT INTO membership (name, email, status, created_at, updated_at, club_id) VALUES (%(name)s, %(email)s, %(status)s, NOW(), NOW(), %(club_id)s );"
        return connectToMySQL(cls.DB).query_db(query, data)
    
    @classmethod
    def get_members_by_club(cls, club_id):
        query = "SELECT * FROM membership WHERE club_id = %(club_id)s"
        members = []
        results = connectToMySQL(cls.DB).query_db(query, {'club_id':club_id})
        for row in results:
            members.append(cls(row))
        return members