from flask_app.config.mysqlconnection import connectToMySQL

from flask import flash

class Movie:
    DB = "movie_club"
    def __init__( self , data ):
        self.id = data['id']
        self.title = data['title']
        self.date_watched = data['date_watched']
        self.release_year = data['release_year']
        self.genres = data['genres']
        self.runtime = data['runtime']
        self.imdb = data['imdb']
        self.metacritic = data['metacritic']
        self.age_rating = data['age_rating']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']

    @classmethod
    def save(cls, data ):
        query = "INSERT INTO movies ( title , release_date , date_watched, runtime, club_id, created_at , updated_at ) VALUES ( %(title)s, %(release_date)s, %(date_watched)s, %(runtime)s, %(club_id)s, NOW() , NOW() );"
        return connectToMySQL(cls.DB).query_db( query, data )
    
    @classmethod
    def get_by_id(cls,club_id):
        query = "SELECT * FROM movies WHERE club_id = %(club_id)s;"
        movies = []
        results = connectToMySQL(cls.DB).query_db(query,{'club_id':club_id})
        for m in results:
            movies.append(m)
        return movies